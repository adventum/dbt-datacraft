def get_provider_info():
    return {
        "package-name": "apache-airflow-providers-datacraft",
        "name": "Apache Airflow Providers Datacraft",
        "description": "Module for Datacraft of Apache Airflow providers for etlCraft",
        "version": ["0.0.1"],
    }
